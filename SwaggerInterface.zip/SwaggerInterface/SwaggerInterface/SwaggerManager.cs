﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

namespace SwaggerInterface
{
    public class SwaggerManager
    {
       
        public static Coordinates londonCoordinates = new Coordinates(51.507359, -0.136439);

        public string GetRequest(string query)
        {
            string response = "";
            try
            {
                //rest url
                string url = "https://bpdts-test-app.herokuapp.com/" + query;

                var client = new WebClient();
                response = client.DownloadString(url);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
     
        public string GetLondonUsers()
        {
            string result = "";
            try
            {
                string queryString = "city/London/users";
                result = GetRequest(queryString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public string GetAllUsers()
        {
            string result = "";
            try
            {
                string queryString = "users";
                result = GetRequest(queryString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        //create a new list combining both the london users and those within 50 miles removing the duplicate users that fall into both categories
        private static List<User> CompareLists(List<User> list1, List<User> list2)
        {
            List<User> commonList = new List<User>();
            try
            {

                var notTheseIds = list1.Select(u => u.id);
                commonList = (from f in list2
                                         where !notTheseIds.Contains(f.id)
                                         select f).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return commonList;
        }
        
        public List<User> GetAllUsersInAndAroundLondon()
        {
            List<User> combinedUsers = new List<User>();
            try
            {
                List<User> allUsersWithin50MilesOfLondon = GetAllUsersWithin50MilesOfLondon();
                List<User> allUsersLivingInLondon = GetAllUsersLivingInLondon();

                combinedUsers = CompareLists(allUsersLivingInLondon, allUsersWithin50MilesOfLondon);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return combinedUsers;

        }
            

         // All users returned are within x miles of London
         public List<User> GetAllUsersWithin50MilesOfLondon()
        {
            List<User> allUserWithin50Miles = null;

            try
            {

                string allUsersResponse = GetAllUsers();
            
                List<User> allUsers = JsonConvert.DeserializeObject<List<User>>(allUsersResponse);

                allUserWithin50Miles = new List<User>();
                foreach (User item in allUsers)
                {

                    var distance = new Coordinates(item.latitude, item.longitude)
                            .DistanceTo(
                                londonCoordinates,
                                UnitOfLength.Miles
                            );

                    if (distance <= 80467.2) //distance is in metres so 50 miles * 1,609.344 = 80467.2 metres
                    {
                        allUserWithin50Miles.Add(item);
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return allUserWithin50Miles;
        }

        public List<User> GetAllUsersLivingInLondon()
        {
            List<User> allUsersInLondon = null;

            try
            {
                string allLondonUsersReq = GetLondonUsers();
                allUsersInLondon = JsonConvert.DeserializeObject<List<User>>(allLondonUsersReq);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return allUsersInLondon;
        }

    }
}
